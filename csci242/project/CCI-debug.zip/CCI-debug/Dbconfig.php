<?php
/**
 * Database configuration file
 * configure database connection data
 * @author Yaxing Chen
 * @team SET
 * @date 03/25/2011
 */

return array(
	'host' => 'mysql2.myregisteredsite.com', 
    'user' => '175192_crmtest',
	'pwd' => 'crmtestcsci242',
	'dbName' => '175192_CRM_Test'
	//'host' => 'localhost', 
    //'user' => 'root',
	//'pwd' => '',
	//'dbName' => '175192_CRM_Test'
);

?>