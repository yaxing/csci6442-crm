<?php
/**
 * Create Service
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/18/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// location_type
$location_type = $_POST["location_type"];

//$location_type = 'aaa';

// prepare the sql statements
//location_type
$sql_location_type = "INSERT INTO ".$db_name.".location_type VALUES ('".$location_type."');";
//echo $sql_location_type;
//die();
$db->insert($sql_location_type);
//echo $sql_account ."\n<br>";
echo $sql_location_type;

?>