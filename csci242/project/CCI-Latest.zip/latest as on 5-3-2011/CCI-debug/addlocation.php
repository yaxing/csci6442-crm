<?php
/**
 * Update Location
 * 
 * @author Varun Maliwal
 * @team SALES
 * @date 04/25/2011
 */


#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include
$db = new Database();
$db_name = "175192_CRM_Test";

$contact_id = $_POST["contactid"];
//$contact_id = "1";
$customer_id = $_POST["customerid"];
//$customer_id = "1";
$zipcode = $_POST["zipcode"];// "40012";
//$zipcode = "42222";
$address1 = $_POST["address1"];//"Budlong AVE";//
//$address1 = "ABCD";
$address2 = $_POST["address2"];//"APT123";//
//$address2 = "BCDE";
$city = $_POST["city"];//"Los Angeles";//
//$city = "VA";
$state = $_POST["state"];//"CA";//
//$state = "VA";
$location_type= $_POST["type"];//"Home";//
//$location_type = "Branch";



// prepare the sql statements
// add location information	
    $sql_account_location = "INSERT INTO ".$db_name.".location_info VALUES (null, '".$zipcode."', '".$address1."', '".$address2."', '".$city."', '".$state."', '".$location_type."');";
    $account_location_id = $db->insert($sql_account_location);
	echo $account_location_id."\n<br>";
	$sql_account_person_location = "INSERT INTO ".$db_name.".contact_location VALUES (".$contact_id.", ".$account_location_id.");";
	$account_person_location_id = $db->insert($sql_account_person_location);
	$sql_account_location = "INSERT INTO ".$db_name.".customer_location VALUES (".$customer_id.", ".$account_location_id.");";
	$account_location_id1 = $db->insert($sql_account_location);
	echo $sql_account_location."\n<br>";
	echo $sql_account_person_location."\n<br>";
?>