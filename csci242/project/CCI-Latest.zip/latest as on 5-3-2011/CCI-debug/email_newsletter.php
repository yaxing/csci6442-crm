<?php
/**
 * News Management
 * 
 * @author Tianyou Li
 * @team SALES
 * @date 05/01/2010
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

//SET UP VARIABLES
//-->newsletter_information table
$newsletter_id = "1";//$_POST["1";]//["news_id"];//"1";//
$description = "d232";//$_POST["d232"];//["news_content"];//"d232";//
$heading = "  wefwe";//$_POST["  wefwe"];//["news_title"];//"  wefwe";//
$data = file("template.html");
$content = '';
foreach($data as $value) {
	if (trim($value) == '##description'){
		$content .= $description;
	}
	else $content .= $value;
	
	
}
echo $content.'<br>';
$description .='';
//echo $newsletter_id;
//echo $description;
//echo $heading;

if (empty($description) && empty($heading))
	return;
if (empty($description))
	$sql_newsletter = "UPDATE ".$db_name.".newsletter_information SET heading='".$heading."' WHERE newsletter_id=".$newsletter_id.";";
else if (empty($heading))	
	$sql_newsletter = "UPDATE ".$db_name.".newsletter_information SET description='".$description."' WHERE newsletter_id=".$newsletter_id.";";
else
	$sql_newsletter = "UPDATE ".$db_name.".newsletter_information SET description='".$description."', heading='".$heading."' WHERE newsletter_id=".$newsletter_id.";"; 
$sql_newsletter_id = $db->update($sql_newsletter);
$to ="";
if ($sql_newsletter_id >= 0) {
	//send email to all email address	
	$sql_emails = "SELECT value FROM ".$db_name.".contact_communication WHERE type_of_communication='Email'";
	$db->select($sql_emails);
	$result = $db->fetchAssoc();

	for($i = 0; $i < count($result); $i++)
	{	if ($i == count($result)-1)
			$to .= $result[$i]['value'];
		else $to .= $result[$i]['value'].",";
	}
	echo $to;
	$subject = $heading;
	$body = $content;
	$headers = "From: cs242-do-not-reply@consultcity.com\r\n"."X-Mailer: php". phpversion();
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	// Additional headers
	//$headers .= 'To: Kevin <kevin.ltyou@gmail.com>, Tianyou Li<ltyou@gwu.edu>' . "\r\n";
	$headers .= "From: cs242-do-not-reply@consultcity.com\r\n"."X-Mailer: php". phpversion();
	//$headers .= 'Bcc: ltyou@msn.com' . "\r\n";	
	  //returns 1 for success, -1 for failure	 
 	if (mail($to, $subject, $body, $headers)) {
   	     echo '<emailed>1</emailed>';
  	} else {
   	    echo '<emailed>-1</emailed>';
  	}
}
//get contract id
echo $sql_newsletter."\n<br>";
echo $sql_newsletter_id."\n<br>";

?>