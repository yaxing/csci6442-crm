<?php
/**
 * Update Location
 * 
 * @author Varun Maliwal
 * @team SALES
 * @date 04/25/2011
 */


#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include
$db = new Database();
$db_name = "175192_CRM_Test";

$contactid = $_POST["contactid"];
//$contactid = "1";
$typeofcommunication = $_POST["type_of_communication"];
//$typeofcommunication = "Email";
$value = $_POST["value"];
//$value = "234456778";



// prepare the sql statements
// add location information	
    $sql_com = "INSERT INTO ".$db_name.".contact_communication VALUES (null,null, ".$contactid.", null, '".$typeofcommunication."', '".$value."');";
    $comm = $db->insert($sql_com);
	echo $comm."\n<br>";
	
?>