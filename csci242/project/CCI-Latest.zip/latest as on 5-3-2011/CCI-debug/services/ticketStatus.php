<?php
/**
 * Customer Management
 * 
 * @author Anbing Xue
 * @team SALES
 * @date 04/26/2010
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

//SET UP VARIABLES
//-->Ticket table
$ticket_id = $_POST["Ticket_Id"];
$ticket_description = $_POST["Ticket_Description"];
$ticket_summary = $_POST["Ticket_Summary"];
$ticket_status = $_POST["Ticket_Status"];
//$customer_name = $_POST["Customer_Name"];
//$website = $_POST["Website"];
//$date_entered = $_POST["Date_Entered"];
//$customer_type = $_POST["Customer_Type"];
//$status = $_POST["Status"];
//$date_entered = date("Y-m-d H:i:s",mktime());
//$date_entered = date("Y-m-d",mktime(0,0,0,substr($date_entered,0,2),substr($date_entered,3,2),substr($date_entered,6,4)));
//UPDATE 175192_CRM_Test.customer SET customer_name="CCI", website="www.consultcity.com", date_entered="2011-04-01", customer_type="Company", status="Customer" WHERE customer_id=1
//$sql_customer_equipment = "INSERT INTO ".$db_name.".customer_equipment VALUES (null,'".$equipment_name."', '".$specification."', '".$contract_id."','".$qty."');"; 
/*
$customer_id = 1;
$website="adbad";
$customer_name= "CCI";
$customer_type="Individual";
$status="Customer";
*/
//$sql_ticket = "UPDATE ".$db_name.".ticket SET ticket_satuts='".$ticket_status."' WHERE ticket_id=".$ticket_id.";"; 
$ticket_status = "Approved";
//$ticket_id = 4;
$sql_ticket = "UPDATE ".$db_name.".ticket SET ticket_status='".$ticket_status."' WHERE ticket_id=".$ticket_id.";"; 
$sql_ticket_id = $db->update($sql_ticket);

//get contract id
echo $sql_ticket."\n<br>";
echo $sql_ticket_id."\n<br>";

if($ticket_status == "Approved"){
        $sql = "select * from ticket where ticket_id = ".$ticket_id;
        $db->select($sql);
        $result = $db->fetchAssoc();
        $ticketSummary = $result[0]["ticket_summary"];
        $body = "Your ticket about '".$ticketSummary."' has been officially closed.";
        $subject = "Ticket closed";
        $contact_id = $result[0]["contact_id"];
        
        $sql = "select value from contact_communication where contact_id = ".$contact_id." and type_of_communication = 'Email'";
        $db->select($sql);
        $result = $db->fetchAssoc();
        
        for($i = 0; $i < count($result); $i ++){
                $email = $result[$i]["value"];
                email($email, $subject, $body);
        }       
}

?>