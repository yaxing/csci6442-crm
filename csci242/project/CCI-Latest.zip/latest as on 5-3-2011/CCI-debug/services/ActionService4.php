<?php

/**
 *  README for sample service
 *
 *  This generated sample service contains functions that illustrate typical service operations.
 *  Use these functions as a starting point for creating your own service implementation. Modify the 
 *  function signatures, references to the database, and implementation according to your needs. 
 *  Delete the functions that you do not use.
 *
 *  Save your changes and return to Flash Builder. In Flash Builder Data/Services View, refresh 
 *  the service. Then drag service operations onto user interface components in Design View. For 
 *  example, drag the getAllItems() operation onto a DataGrid.
 *  
 *  This code is for prototyping only.
 *  
 *  Authenticate the user prior to allowing them to call these methods. You can find more 
 *  information at http://www.adobe.com/go/flex_security
 *
 */
class ActionService4 {

	var $username = "175192_crmtest";
	var $password = "crmtestcsci242";
	var $server = "mysql2.myregisteredsite.com";
	var $port = "3306";
	var $databasename = "175192_CRM_Test";
	var $tablename = "action";

	var $connection;

	/**
	 * The constructor initializes the connection to database. Everytime a request is 
	 * received by Zend AMF, an instance of the service class is created and then the
	 * requested method is invoked.
	 */
	public function __construct() {
	  	$this->connection = mysqli_connect(
	  							$this->server,  
	  							$this->username,  
	  							$this->password, 
	  							$this->databasename,
	  							$this->port
	  						);

		$this->throwExceptionOnError($this->connection);
	}

	/**
	 * Returns all the rows from the table.
	 *
	 * Add authroization or any logical checks for secure access to your data 
	 *
	 * @return array
	 */
	public function getAllAction() {

		$stmt = mysqli_prepare($this->connection, "SELECT * FROM $this->tablename");		
		$this->throwExceptionOnError();
		
		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
		$rows = array();
		
		mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
		
	    while (mysqli_stmt_fetch($stmt)) {
	      $row->requested_completion = new DateTime($row->requested_completion);
	      $row->actual_completion = new DateTime($row->actual_completion);
	      $rows[] = $row;
	      $row = new stdClass();
	      mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
	    }
		
		mysqli_stmt_free_result($stmt);
	    mysqli_close($this->connection);
	
	    return $rows;
	}

	/**
	 * Returns the item corresponding to the value specified for the primary key.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * 
	 * @return stdClass
	 */
	public function getActionByID($itemID) {
		
		$stmt = mysqli_prepare($this->connection, "SELECT * FROM $this->tablename where action_id=?");
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_param($stmt, 'i', $itemID);		
		$this->throwExceptionOnError();
		
		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
		
		if(mysqli_stmt_fetch($stmt)) {
	      $row->requested_completion = new DateTime($row->requested_completion);
	      $row->actual_completion = new DateTime($row->actual_completion);
	      return $row;
		} else {
	      return null;
		}
	}
	
	
		public function getActionBy_TicketID($itemID) {
		
		$stmt = mysqli_prepare($this->connection, "SELECT * FROM $this->tablename where parent_ticket=?");
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_param($stmt, 'i', $itemID);		
		$this->throwExceptionOnError();
		
		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
	/*	mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
		
		if(mysqli_stmt_fetch($stmt)) {
	      $row->requested_completion = new DateTime($row->requested_completion);
	      $row->actual_completion = new DateTime($row->actual_completion);
	      return $row;
		} else {
	      return null;
		} */
		$rows = array();
		
		mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
		
	    while (mysqli_stmt_fetch($stmt)) {
	      $row->requested_completion = new DateTime($row->requested_completion);
	      $row->actual_completion = new DateTime($row->actual_completion);
	      $rows[] = $row;
	      $row = new stdClass();
	      mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
	    }
		
		mysqli_stmt_free_result($stmt);
	    mysqli_close($this->connection);
	
	    return $rows;
		
	}

	/**
	 * Returns the item corresponding to the value specified for the primary key.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * 
	 * @return stdClass
	 */
	public function createAction($item) {

		$stmt = mysqli_prepare($this->connection, "INSERT INTO $this->tablename (parent_ticket, assigned_to_agent, assigned_to_skill, action_created_by, action_prob_description, action_solution_description, percent_completed, agent_rating, requested_completion, actual_completion, action_priority, billable, action_status, comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$this->throwExceptionOnError();

		mysqli_stmt_bind_param($stmt, 'iisissiisssiss', $item->parent_ticket, $item->assigned_to_agent, $item->assigned_to_skill, $item->action_created_by, $item->action_prob_description, $item->action_solution_description, $item->percent_completed, $item->agent_rating, $item->requested_completion->toString('YYYY-MM-dd HH:mm:ss'), $item->actual_completion->toString('YYYY-MM-dd HH:mm:ss'), $item->action_priority, $item->billable, $item->action_status, $item->comment);
		$this->throwExceptionOnError();

		mysqli_stmt_execute($stmt);		
		$this->throwExceptionOnError();

		$autoid = mysqli_stmt_insert_id($stmt);

		mysqli_stmt_free_result($stmt);		
		mysqli_close($this->connection);

		return $autoid;
	}

	/**
	 * Updates the passed item in the table.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * @param stdClass $item
	 * @return void
	 */
	public function updateAction($item) {
	
		$stmt = mysqli_prepare($this->connection, "UPDATE $this->tablename SET parent_ticket=?, assigned_to_agent=?, assigned_to_skill=?, action_created_by=?, action_prob_description=?, action_solution_description=?, percent_completed=?, agent_rating=?, requested_completion=?, actual_completion=?, action_priority=?, billable=?, action_status=?, comment=? WHERE action_id=?");		
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_param($stmt, 'iisissiisssissi', $item->parent_ticket, $item->assigned_to_agent, $item->assigned_to_skill, $item->action_created_by, $item->action_prob_description, $item->action_solution_description, $item->percent_completed, $item->agent_rating, $item->requested_completion->toString('YYYY-MM-dd HH:mm:ss'), $item->actual_completion->toString('YYYY-MM-dd HH:mm:ss'), $item->action_priority, $item->billable, $item->action_status, $item->comment, $item->action_id);		
		$this->throwExceptionOnError();

		mysqli_stmt_execute($stmt);		
		$this->throwExceptionOnError();
		
		mysqli_stmt_free_result($stmt);		
		mysqli_close($this->connection);
	}

	/**
	 * Deletes the item corresponding to the passed primary key value from 
	 * the table.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * 
	 * @return void
	 */
	public function deleteAction($itemID) {
				
		$stmt = mysqli_prepare($this->connection, "DELETE FROM $this->tablename WHERE action_id = ?");
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_param($stmt, 'i', $itemID);
		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
		mysqli_stmt_free_result($stmt);		
		mysqli_close($this->connection);
	}


	/**
	 * Returns the number of rows in the table.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * 
	 */
	public function count() {
		$stmt = mysqli_prepare($this->connection, "SELECT COUNT(*) AS COUNT FROM $this->tablename");
		$this->throwExceptionOnError();

		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_result($stmt, $rec_count);
		$this->throwExceptionOnError();
		
		mysqli_stmt_fetch($stmt);
		$this->throwExceptionOnError();
		
		mysqli_stmt_free_result($stmt);
		mysqli_close($this->connection);
		
		return $rec_count;
	}


	/**
	 * Returns $numItems rows starting from the $startIndex row from the 
	 * table.
	 *
	 * Add authorization or any logical checks for secure access to your data 
	 *
	 * 
	 * 
	 * @return array
	 */
	public function getAction_paged($startIndex, $numItems) {
		
		$stmt = mysqli_prepare($this->connection, "SELECT * FROM $this->tablename LIMIT ?, ?");
		$this->throwExceptionOnError();
		
		mysqli_stmt_bind_param($stmt, 'ii', $startIndex, $numItems);
		mysqli_stmt_execute($stmt);
		$this->throwExceptionOnError();
		
		$rows = array();
		
		mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
		
	    while (mysqli_stmt_fetch($stmt)) {
	      $row->requested_completion = new DateTime($row->requested_completion);
	      $row->actual_completion = new DateTime($row->actual_completion);
	      $rows[] = $row;
	      $row = new stdClass();
	      mysqli_stmt_bind_result($stmt, $row->action_id, $row->parent_ticket, $row->assigned_to_agent, $row->assigned_to_skill, $row->action_created_by, $row->action_prob_description, $row->action_solution_description, $row->percent_completed, $row->agent_rating, $row->requested_completion, $row->actual_completion, $row->action_priority, $row->billable, $row->action_status, $row->comment);
	    }
		
		mysqli_stmt_free_result($stmt);		
		mysqli_close($this->connection);
		
		return $rows;
	}
	
	
	/**
	 * Utility function to throw an exception if an error occurs 
	 * while running a mysql command.
	 */
	private function throwExceptionOnError($link = null) {
		if($link == null) {
			$link = $this->connection;
		}
		if(mysqli_error($link)) {
			$msg = mysqli_errno($link) . ": " . mysqli_error($link);
			throw new Exception('MySQL Error - '. $msg);
		}		
	}
}

?>
