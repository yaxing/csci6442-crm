<?php
	
	/**
	 * Dispatcher views all actions
	 * 
	 * @author Alex Florescu
	 * @team Services
	 * @date 04/02/2011
	 */
	
	
	#region include
	include_once 'header.php';
	#endregion include
	
	$contact_id=$_POST['contact_id']; 
	//execute statement
	$sql = "SELECT * FROM contact WHERE contact_id='$contact_id';";
	
	$db->select($sql);
	$result = $db->fetchAssoc();
	
	foreach ($result as $index => $row) {
		foreach ($row as $column => $value)
		echo "<$column>$value</$column>\n";
	}		 		
	
	?>