<?php
/**
 * Update Location
 * 
 * @author Varun Maliwal
 * @team SALES
 * @date 04/25/2011
 */


#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include
$db = new Database();
$db_name = "175192_CRM_Test";

$communicationType = $_POST["communicationtype"];
//$communicationType = "Email";
$value = $_POST["value"];
//$value = "testofphp@cci.com";

$communication_id = $_POST["communication_id"];
//$communication_id = "1";

// prepare the sql statements
// update location information	
$sql = "UPDATE contact_communication SET value='$value',type_of_communication='$communicationType' WHERE communication_id='$communication_id';";
echo $sql;
$affectedRows = $db->update($sql);
echo $affectedRows;

?>