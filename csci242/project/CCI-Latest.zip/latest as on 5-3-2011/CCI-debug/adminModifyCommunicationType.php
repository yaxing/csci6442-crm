<?php
/**
 * Create Service
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/25/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// contents
$communication_type = $_POST["communication_type"];
//$type_of_content = "service";

$selected_communication_type = $_POST["selected_communication_type"];
//$selected_contents = "bye";
echo $selected_communication_type;


// prepare the sql statements
//contents

	$sql = "UPDATE communication_type SET communication_type='$communication_type' WHERE communication_type='$selected_communication_type';";

	echo $sql;
    $affectedRows = $db->update($sql);
	echo $affectedRows;

//echo $sql_account ."\n<br>";


?>