<?php
/**
 * Create Service
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/18/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// Location_type
$location_type = $_POST["location_type"];
echo $location_type;
$selected_location_type = $_POST["selected_location_type"];
echo $selected_location_type;


// prepare the sql statements
//Service
	$sql = "UPDATE location_type SET location_type='$location_type' WHERE location_type='$selected_location_type';";

	echo $sql;
    $affectedRows = $db->update($sql);
	echo $affectedRows;

//echo $sql_account ."\n<br>";


?>