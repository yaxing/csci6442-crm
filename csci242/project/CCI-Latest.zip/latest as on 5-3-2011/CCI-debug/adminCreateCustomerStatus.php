<?php
/**
 * Create Service
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/25/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// customer_status
$customer_status = $_POST["customer_status"];


// prepare the sql statements
//customer_status
$sql_customer_status = "INSERT INTO ".$db_name.".customer_status VALUES ('".$customer_status."');";
//echo $sql_customer_status;
//die();
$db->insert($sql_customer_status);
//echo $sql_customer_status ."\n<br>";
echo $sql_customer_status;

?>