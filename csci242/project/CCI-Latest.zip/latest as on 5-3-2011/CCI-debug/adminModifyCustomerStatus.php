<?php
/**
 * Modify Customer Status
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/25/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// Customer_status

$customer_status = $_POST["customer_status"];
//$customer_status = "NEW1";

$selected_customer_status = $_POST["selected_customer_status"];
//$selected_customer_status = "New";
//echo $selected_customer_status;
//Customer Status


	$sql = "UPDATE customer_status SET status='$customer_status' WHERE status='$selected_customer_status';";
	echo $sql;
    $affectedRows = $db->update($sql);
	echo $affectedRows;

//echo $sql_account ."\n<br>";


?>