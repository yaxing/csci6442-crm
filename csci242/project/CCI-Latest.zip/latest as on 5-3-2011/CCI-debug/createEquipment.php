<?php
/**
 * Create more equipment
 * 
 * @author Anbing Xue
 * @team SALES
 * @date 04/17/2010
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

//SET UP VARIABLES
//-->customer_equipment table
$contract_id = $_POST["Contract_Id"];
$equipment_name = $_POST["Equipment_Name"];
$specification = $_POST["Specification"];
$qty=$_POST["Quantity"];
// customer_id
$customer_id = $_POST["Customer_ID"];
//location_id
$location_id = $_POST["Location_Id"];

/*
$equipment_name="test";
$qty=12;
$customer_id=1;
$location_id=1;
$contract_id=37;
*/
//insert customer_equipment
$sql_customer_equipment = "INSERT INTO ".$db_name.".customer_equipment VALUES (null,'".$equipment_name."', '".$specification."','".$qty."', '".$customer_id."', '".$location_id."');"; 
$customer_equipment_id = $db->insert($sql_customer_equipment);
//echo $customer_equipment_id."\n<br>";

//insert contract_equipment
$sql_contract_equipment = "INSERT INTO ".$db_name.".contract_equipment VALUES ('".$customer_equipment_id."', '".$contract_id."', '".$qty."');"; 
$returnVal=$db->insert($sql_contract_equipment);

//get returnVal
echo "<CALCU>";
echo "<CALCUS>";
echo "<RETURNVAL>".$returnVal."</RETURNVAL>";
echo "</CALCUS>";
echo "</CALCU>";
//echo $sql_customer_equipment."\n<br>";
//echo $sql_contract_equipment."\n<br>";

?>