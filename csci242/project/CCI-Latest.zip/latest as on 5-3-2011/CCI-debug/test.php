<?php
/**
 * Create Service
 * 
 * @author Sharvani Tota
 * @team SALES
 * @date 04/16/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

$customer_id = $_POST["customer_id"];
//$customer_id = "1";
$sql = "SELECT concat(first_name,' ',last_name) AS contactname FROM contact WHERE customer = $customer_id";

	$db->select($sql);
	$result = $db->fetchAssoc();
	
	foreach ($result as $index => $row) {
		echo "<contact>\n";
		foreach ($row as $column => $value)
			echo "<$column>$value</$column>\n";
		echo "</contact>\n\n";
     }  
	   
?>