<?php
/**
 * Create Service
 * 
 * @author Sharvani Tota
 * @team SALES
 * @date 04/16/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// Service_Name
$service_level = $_POST["service_level"];
// Description
$discount = $_POST["discount"];
//Selected_Service_Name
$selected_service_level = $_POST["selected_service_level"];

// prepare the sql statements
//Service
	$sql = "UPDATE service_levels SET service_level='$service_level',discount_given=$discount 
	WHERE service_level='$selected_service_level';";
	echo $sql;
    $affectedRows = $db->update($sql);
	echo $affectedRows;

//echo $sql_account ."\n<br>";


?>