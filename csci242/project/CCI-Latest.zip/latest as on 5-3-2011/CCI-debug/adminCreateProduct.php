<?php
/**
 * Create Contract
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/19/2010
 *       04/19/2010
 *			Use Customer instead of Account;
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

//SET UP VARIABLES
//-->product table
// Account_Name

//echo "helllooooooooooooooooooo";

$customer_id = $_POST["Customer_ID"];

//Product_name
$product_name = $_POST["product_name"];

//start_date
//$start_date = $_POST["start_date"];

//End_Date
$end_date = $_POST["end_date"];

//sent_to
$sent_to = $_POST["sent_to"];

//Location_Id
$Location_Id = $_POST["Location_Id"];

//Price
$price = $_POST["price"];

//quantity
$quantity = $_POST["quantity"];

//taxable
$taxable = $_POST["taxable"];

//shipping
$shipping = $_POST["shipping"];

//link
$link = $_POST["link"];

//product_specifications
$product_specifications = $_POST["product_specifications"];

//$myFile = "c:\\testFile.txt";
//$fh = fopen($myFile, 'w') ;
//fwrite($fh, "customer id");
//fwrite($fh, $customer_id);

//fwrite($fh, "product name =");
//fwrite($fh, $product_name);

//fwrite($fh, "start date =");
//fwrite($fh, $start_date);

//fwrite($fh, "end date =");
//fwrite($fh, $end_date);

//fwrite($fh, "sent to =");
//fwrite($fh, $sent_to);

//fwrite($fh, "location =");
//fwrite($fh, $Location_Id);

//fwrite($fh, "price =");
//fwrite($fh, $price);

//fwrite($fh, "quantity =");
//fwrite($fh, $quantity);

//fwrite($fh, "taxable =");
//fwrite($fh, $taxable);

//fwrite($fh, "shipping =");
//fwrite($fh, $shipping);

//fwrite($fh, "link =");
//fwrite($fh, $link);


//fclose($fh);


$ticket=1;


$datetime = date("Y-m-d H:i:s",mktime());
$end_date = date("Y-m-d",mktime(0,0,0,substr($end_date,0,2),substr($end_date,3,2),substr($end_date,6,4)));

//$myFile = "testFile.txt";
//$fh = fopen($myFile, 'w') or die("can't open file");
//$stringData = "Floppy Jalopy\n";
//fwrite($fh, $stringData);
//$stringData = "Pointy Pinto\n";
//fwrite($fh, $stringData);
//fclose($fh);


// prepare the sql statements
//insert product

$sql_product = "INSERT INTO `175192_CRM_Test`.`product`(`quantity`,`price`,`link`,`shipping`,`product_name`,`product_specifications`,`taxable`,`sent_to`,`customer_location`,`ticket_id`,`product_id`) VALUES ('".$quantity."', '".$price."', '".$link."', '".$shipping."', '".$product_name."', '".$product_specifications."' , '".$taxable."', '".$sent_to."', '".$Location_Id."', '".$ticket."',null);";

//$contract_id = $db->insert($sql_contract);


$db->insert($sql_product);


echo $sql_product;

?>