<?php
/**
 * Create Contents
 *
 * @author Diptanu Das
 * @team SALES
 * @date 04/25/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php';
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
// Contents
$communication_type = $_POST["communication_type"];

//$location_type = 'aaa';

// prepare the sql statements
//Contents
$sql_communication_type = "INSERT INTO ".$db_name.".communication_type VALUES ('".$communication_type."');";
//echo $sql_location_type;
//die();
$db->insert($sql_communication_type);
//echo $sql_account ."\n<br>";

echo $sql_communication_type;

?>