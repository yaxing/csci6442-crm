<?php
/**
 * Create Contract
 * 
 * @author Anbing Xue
 * @team SALES
 * @date 04/10/2011
 *       04/16/2011 
 *			Use Customer instead of Account;
 *		 04/30/2011
 *			Add contract_equipment insertion
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";

//SET UP VARIABLES
//-->contract table
// Account_Name
$customer_id = $_POST["Customer_ID"];
//Start_Date
$start_date = $_POST["Start_Date"];
//End_Date
$end_date = $_POST["End_Date"];
//Service_Name
$service_name = $_POST["Service_Name"];
//Service_Level
$service_level = $_POST["Service_Level"];
//Location_Id
$location_id = $_POST["Location_Id"];
//Price
$price = $_POST["Price"];
//ticket_id
$ticket_id = $_POST["Ticket_ID"];

$datetime = date("Y-m-d H:i:s",mktime());
$end_date = date("Y-m-d",mktime(0,0,0,substr($end_date,0,2),substr($end_date,3,2),substr($end_date,6,4)));

//-->customer_equipment table
$equipment_name = $_POST["Equipment_Name"];
$specification = $_POST["Specification"];
//$contract_id = $_POST["Contract_Id"];
$qty=$_POST["Quantity"];

// prepare the sql statements
//insert contract
//$ticket_id =1; //to be solved
$sql_contract = "INSERT INTO ".$db_name.".contract VALUES (null, '".$datetime."', '".$end_date."', '".$service_name."', '".$service_level."', '".$customer_id."', '".$location_id."', '".$price."', '".$ticket_id."');"; 
//$sql_contract = "INSERT INTO ".$db_name.".contract VALUES (null, '".$datetime."', '2011/04/30', 'Pc', 'gold', '1', '1','200', '1');"; 
$contract_id = $db->insert($sql_contract);
//echo "sql_contract ".$sql_contract." \n<br>";
//echo "CONTRACT_ID ".$contract_id." \n<br>";

//insert customer_equipment
$sql_customer_equipment = "INSERT INTO ".$db_name.".customer_equipment VALUES (null,'".$equipment_name."', '".$specification."','".$qty."', '".$customer_id."', '".$location_id."');"; 
//$sql_customer_equipment = "INSERT INTO ".$db_name.".customer_equipment VALUES (null,'pc', 'pc screen', '1','20');"; 
//echo "customer_equipment: ".$sql_customer_equipment."\n<br>";
$customer_equipment_id = $db->insert($sql_customer_equipment);

//insert contract_equipment
$sql_contract_equipment = "INSERT INTO ".$db_name.".contract_equipment VALUES ('".$customer_equipment_id."', '".$contract_id."', '".$qty."');"; 
$db->insert($sql_contract_equipment);

//get contract id
echo "<CALCU>";
echo "<CALCUS>";
echo "<CONTRACT_ID>".$contract_id."</CONTRACT_ID>";
echo "<EQU> ".$sql_contract ."</EQU>";
echo "</CALCUS>";
echo "</CALCU>";
?>