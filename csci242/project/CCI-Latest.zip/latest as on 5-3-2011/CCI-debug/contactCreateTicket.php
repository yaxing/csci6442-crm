<?php
	
	/**
	 * Customer creates a ticket
	 * 
	 * @author Alex Florescu
	 * @author Krista Bacungan
	 * @team Services
	 * @date 04/02/2011
	 */
	
	
	#region include
	include_once 'header.php';
	#endregion include
	
	
	// variables in form 
	$description=$_POST['description']; 
	$ticket_summary=$_POST['description']; 
	// CHANGE
	$applicant=1;//$_POST['applicant'];
	// Locations for customer should be available in UI for choosing
	$customer_location_id=$_POST['location'];
	$customer_priority = $_POST['priority'];
	$requested_completion=$_POST['completion_date'];
	$ticket_type=$_POST['ticket_type'];
	$created_date='NOW()'; 
	$created_by_worker=1;
	
	$ticket_status='Open';
	
	//************
	// COOKIE FIX ME
	//************
	$assigned_to=1;//$userID;
	
	//execute statement
	$sql = "INSERT INTO ticket VALUES (NULL, '$customer_priority', '$description', '$ticket_summary', $created_date, $created_by_worker, '$ticket_type', '$requested_completion', $assigned_to, $applicant, $customer_location_id, '$ticket_status');";
	
	$affectedRows = $db->update($sql);
	//affected rows should be exactly 1, otherwise report problem
	echo '<affectedRows>'.$affectedRows."</affectedRows>\n"; 
	
	?>