<?php
/**
 * Create Service
 * 
 * @author Sharvani Tota
 * @team SALES
 * @date 04/16/2011
 */

#region include
//include_once '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php'; 
include_once 'Database.class.php';
//include_once '../../config.php';
#endregion include

$db = new Database();
$db_name = "175192_CRM_Test";
//SET UP VARIABLES
$contact_id= $_POST["contactid"];
//$contact_id = "1";
$lastname =$_POST["lastname"];
//$lastname = "VARUN";

// prepare the sql statements
$sql = "UPDATE contact SET last_name = '$lastname' WHERE contact_id='$contact_id';";
echo $sql;
$affectedRows = $db->update($sql);
echo $affectedRows;


?>